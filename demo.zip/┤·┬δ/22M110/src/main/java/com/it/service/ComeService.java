package com.it.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Come;

import java.util.List;

public interface ComeService {
    /**
     * 分页查询
     *
     * @param entity
     * @param page
     * @param limit
     * @return
     */
    Page<Come> selectPage(Come entity, int page, int limit);

    /**
     * 新增
     *
     * @param entity
     * @return
     */
    boolean insert(Come entity);

    /**
     * 删除
     */
    boolean delById(String id);

    /**
     * 编辑
     *
     * @param entity
     * @return
     */
    boolean edit(Come entity);

    /**
     * 单个对象
     *
     * @param id
     * @return
     */
    Come getOne(String id);


    /**
     * 集合
     *
     * @param
     * @return
     */
    List<Come> getList(String userName, String time);
}
