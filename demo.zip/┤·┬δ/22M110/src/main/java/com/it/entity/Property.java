package com.it.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;

import java.io.Serializable;

/**
 * 实体类
 */
@Data
@TableName("gm_property")
public class Property implements Serializable {
    /**
     * 自增长主键
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * 楼号
     */
    private String code;
    /**
     * 单元号
     */
    private String unit;
    /**
     * 门牌号
     */
    private String name;
    /**
     * 房屋类型
     */
    private String brand;
    /**
     * 面积
     */
    private String area;
    /**
     * 是否有住户
     */
    private String state;
    /**
     * 备注
     */
    private String content;
    /**
     * 宿管
     */
    private String staffId;
}