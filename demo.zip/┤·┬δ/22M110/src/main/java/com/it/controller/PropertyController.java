package com.it.controller;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Property;
import com.it.entity.User;
import com.it.service.PropertyService;
import com.it.service.UserService;
import com.it.util.ItdragonUtils;
import com.it.util.Result;
import com.it.util.ResultResponse;
import com.it.util.TableResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 〈固定资产相关实列接口〉<br>
 *
 * @author
 */
@Controller
@RequestMapping("/property")
public class PropertyController {
    @Autowired
    private PropertyService PropertyService;
    @Autowired
    private ItdragonUtils itdragonUtils;
    @Autowired
    private UserService userService;

    /**
     * 管理界面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/index.do")
    public ModelAndView index(ModelAndView mv) {
        mv.setViewName("property/index");
        return mv;
    }

    /**
     * 管理界面列表数据异步加载接口
     *
     * @param entity
     * @param page
     * @param limit
     * @return
     */
    @ResponseBody
    @GetMapping("property.do")
    public TableResultResponse reloadTable(Property entity, int page, int limit) {
        List<Map<String, Object>> infoList = new ArrayList<>();
        Page<Property> pageInfo = PropertyService.selectPage(entity, page, limit);
        for (Property record : pageInfo.getRecords()) {
            Map<String, Object> resultMap = new HashMap<>(16);
            resultMap.put("id", record.getId());
            resultMap.put("code", record.getCode());
            resultMap.put("name", record.getName());
            resultMap.put("brand", record.getBrand());
            resultMap.put("state", record.getState());
            resultMap.put("area", record.getArea());
            resultMap.put("unit", record.getUnit());
            resultMap.put("content", record.getContent());
            infoList.add(resultMap);
        }
        return Result.tableResule(pageInfo.getTotal(), infoList);
    }

    /**
     * 新增界面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/addPage.do")
    public ModelAndView addPage(ModelAndView mv) {
        List<User> userList = userService.getUserInRole("267b5a862b534ffea61b72f90bdcf6cc");
        mv.addObject("userList", userList);
        mv.setViewName("property/addPage");
        return mv;
    }

    /**
     * 新增数据接口
     *
     * @param entity
     * @return
     */
    @ResponseBody
    @PostMapping("/property.do")
    public ResultResponse insert(Property entity) {
        boolean result = PropertyService.insert(entity);
        if (!result) {
            return Result.resuleError("新增失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 编辑界面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/editPage.do")
    public ModelAndView editPage(ModelAndView mv, String id) {
        Property property = PropertyService.getOne(id);
        mv.addObject("property", property);
        List<User> userList = userService.getUserInRole("267b5a862b534ffea61b72f90bdcf6cc");
        mv.addObject("userList", userList);
        mv.setViewName("property/editPage");
        return mv;
    }

    /**
     * 编辑数据接口
     *
     * @param entity
     * @return
     */
    @ResponseBody
    @PutMapping("/property.do")
    public ResultResponse edit(Property entity) {
        boolean result = PropertyService.editById(entity);
        if (!result) {
            return Result.resuleError("编辑失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 删除数据接口
     *
     * @param id
     * @return
     */
    @ResponseBody
    @DeleteMapping("/property.do")
    public ResultResponse delete(String id) {
        boolean result = PropertyService.deleteById(id);
        if (!result) {
            return Result.resuleError("删除失败");
        }
        return Result.resuleSuccess();
    }

}