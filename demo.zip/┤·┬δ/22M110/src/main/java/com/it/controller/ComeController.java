package com.it.controller;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Come;
import com.it.service.ComeService;
import com.it.service.UserService;
import com.it.util.ItdragonUtils;
import com.it.util.Result;
import com.it.util.ResultResponse;
import com.it.util.TableResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 〈〉<br>
 *
 * @author
 * @create 2019/1/16 16:00
 * @since 1.0.0
 */
@Controller
@RequestMapping("/come")
public class ComeController {
    @Autowired
    private ComeService ComeService;
    @Autowired
    private UserService userService;
    @Autowired
    private ItdragonUtils itdragonUtils;


    /**
     * 管理界面跳转
     *
     * @param mv
     * @return
     */
    @RequestMapping("/index.do")
    public ModelAndView index(ModelAndView mv) {

        mv.setViewName("come/index");
        return mv;
    }

    /**
     * 管理界面列表
     *
     * @param entity
     * @param page
     * @param limit
     * @return
     */
    @ResponseBody
    @GetMapping("come.do")
    public TableResultResponse getTables(Come entity, int page, int limit) {
        List<Map<String, Object>> infoList = new ArrayList<>();
        Page<Come> pageInfo = ComeService.selectPage(entity, page, limit);
        for (Come record : pageInfo.getRecords()) {
            Map<String, Object> resultMap = new HashMap<>(16);
            resultMap.put("id", record.getId());
            resultMap.put("content", record.getContent());
            resultMap.put("name", record.getName());
            resultMap.put("number", record.getNumber());
            resultMap.put("iphone", record.getIphone());
            resultMap.put("type", record.getType());
            resultMap.put("sex", record.getSex());
            resultMap.put("time", record.getTime() == null ? "" : record.getTime().substring(0, 19));

            infoList.add(resultMap);
        }
        return Result.tableResule(pageInfo.getTotal(), infoList);
    }

    /**
     * 删除
     *
     * @param id
     * @return
     */
    @ResponseBody
    @DeleteMapping("/come.do")
    public ResultResponse delete(String id) {
        boolean result = ComeService.delById(id);
        if (!result) {
            return Result.resuleError("删除失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 新增界面跳转
     *
     * @param mv
     * @return
     */
    @RequestMapping("/addPage.do")
    public ModelAndView addPage(ModelAndView mv) {
        mv.setViewName("come/addPage");
        return mv;
    }

    /**
     * 新增
     *
     * @param entity
     * @return
     */
    @ResponseBody
    @PostMapping("/come.do")
    public ResultResponse insert(Come entity) {
        boolean result = ComeService.insert(entity);
        if (!result) {
            return Result.resuleError("新增失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 编辑界面跳转
     *
     * @param mv
     * @return
     */
    @RequestMapping("/editPage.do")
    public ModelAndView editPage(ModelAndView mv, String id) {
        Come come = ComeService.getOne(id);
        mv.addObject("come", come);
        mv.setViewName("come/editPage");
        return mv;
    }

    /**
     * 编辑
     *
     * @param entity
     * @return
     */
    @ResponseBody
    @PutMapping("/come.do")
    public ResultResponse update(Come entity) {
        boolean result = ComeService.edit(entity);
        if (!result) {
            return Result.resuleError("编辑失败");
        }
        return Result.resuleSuccess();
    }
}