package com.it.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Guarantee;

import java.util.List;

public interface GuaranteeService {
    /**
     * 分页查询
     *
     * @param entity
     * @param page
     * @param limit
     * @return
     */
    Page<Guarantee> selectPage(Guarantee entity, int page, int limit);

    /**
     * 新增
     *
     * @param entity
     * @return
     */
    boolean insert(Guarantee entity);


    /**
     * 编辑
     *
     * @param entity
     * @return
     */
    boolean editById(Guarantee entity);


    /**
     * 删除
     *
     * @param ids
     * @return
     */

    boolean deleteById(String ids);


    /**
     * 获取集合
     *
     * @param entity
     * @return
     */
    List<Guarantee> getList(Guarantee entity);

    /**
     * 通过id查询单个对象
     *
     * @param id
     * @return
     */
    Guarantee getOne(String id);

}
