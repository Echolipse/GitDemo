package com.it.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Property;
import com.it.mapper.PropertyMapper;
import com.it.service.PropertyService;
import com.it.util.ItdragonUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 *
 *
 */
@Service
public class PropertyServiceImpl implements PropertyService {

    @Resource
    private ItdragonUtils itdragonUtils;
    @Resource
    private PropertyMapper PropertyMapper;

    @Override
    public Page<Property> selectPage(Property entity, int page, int limit) {
        EntityWrapper<Property> searchInfo = new EntityWrapper<>();
        Page<Property> pageInfo = new Page<>(page, limit);
        if (ItdragonUtils.stringIsNotBlack(entity.getName())) {
            searchInfo.like("name", entity.getName());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getCode())) {
            searchInfo.like("code", entity.getCode());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getUnit())) {
            searchInfo.like("unit", entity.getUnit());
        }
        List<Property> resultList = PropertyMapper.selectPage(pageInfo, searchInfo);
        if (!resultList.isEmpty()) {
            pageInfo.setRecords(resultList);
        }
        return pageInfo;
    }

    @Override
    public boolean insert(Property entity) {
        Integer insert = PropertyMapper.insert(entity);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean editById(Property entity) {
        Integer insert = PropertyMapper.updateById(entity);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteById(String ids) {
        String[] idList = ids.split(",");
        int result = 0;
        for (String s : idList) {
            result = PropertyMapper.deleteById(s);
        }
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public List<Property> getList(Property entity) {
        EntityWrapper<Property> wrapper = new EntityWrapper<>();
        if (ItdragonUtils.stringIsNotBlack(entity.getName())) {
            wrapper.eq("name", entity.getName());
        }
        List<Property> resultList = PropertyMapper.selectList(wrapper);
        return resultList;
    }

    @Override
    public Property getOne(String id) {
        return PropertyMapper.selectById(id);
    }


}