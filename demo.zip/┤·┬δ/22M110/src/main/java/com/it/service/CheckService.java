package com.it.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Check;

import java.util.List;

public interface CheckService {
    /**
     * 分页查询
     *
     * @param entity
     * @param page
     * @param limit
     * @return
     */
    Page<Check> selectPage(Check entity, int page, int limit);

    /**
     * 新增
     *
     * @param entity
     * @return
     */
    boolean insert(Check entity);

    /**
     * 编辑
     *
     * @param entity
     * @return
     */
    boolean editById(Check entity);

    /**
     * 删除
     *
     * @param ids
     * @return
     */

    boolean deleteById(String ids);

    /**
     * 获取集合
     *
     * @param entity
     * @return
     */
    List<Check> getList(Check entity);
    List<Check> getList(String userId, String time, String state);

    /**
     * 通过id查询单个对象
     *
     * @param id
     * @return
     */
    Check getOne(String id);

}
