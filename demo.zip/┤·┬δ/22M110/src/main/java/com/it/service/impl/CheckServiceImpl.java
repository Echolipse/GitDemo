package com.it.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Check;
import com.it.mapper.CheckMapper;
import com.it.service.CheckService;
import com.it.util.DateUtil;
import com.it.util.ItdragonUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 *
 *
 */
@Service
public class CheckServiceImpl implements CheckService {

    @Resource
    private ItdragonUtils itdragonUtils;
    @Resource
    private CheckMapper CheckMapper;

    @Override
    public Page<Check> selectPage(Check entity, int page, int limit) {
        EntityWrapper<Check> searchInfo = new EntityWrapper<>();
        Page<Check> pageInfo = new Page<>(page, limit);
        if (ItdragonUtils.stringIsNotBlack(entity.getUserId())) {
            searchInfo.eq("userId", entity.getUserId());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getType())) {
            searchInfo.eq("type", entity.getType());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getUserName())) {
            searchInfo.eq("userName", entity.getUserName());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getTime())) {
            searchInfo.between("time", entity.getTime().split(" - ")[0], entity.getTime().split(" - ")[1]);
        }
        searchInfo.orderBy("time desc");
        List<Check> resultList = CheckMapper.selectPage(pageInfo, searchInfo);
        if (!resultList.isEmpty()) {
            pageInfo.setRecords(resultList);
        }
        return pageInfo;
    }

    @Override
    public boolean insert(Check entity) {
        entity.setTime(DateUtil.getNowDateSS());
        entity.setUserId(itdragonUtils.getSessionUserId());
        entity.setUserName(itdragonUtils.getSessionUserName());
        Integer insert = CheckMapper.insert(entity);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean editById(Check entity) {
        Integer insert = CheckMapper.updateById(entity);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteById(String ids) {
        String[] idList = ids.split(",");
        int result = 0;
        for (String s : idList) {
            result = CheckMapper.deleteById(s);
        }
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public List<Check> getList(Check entity) {
        EntityWrapper<Check> wrapper = new EntityWrapper<>();
        if (ItdragonUtils.stringIsNotBlack(entity.getUserId())) {
            wrapper.eq("userId", entity.getUserId());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getUserName())) {
            wrapper.eq("userName", entity.getUserName());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getTime())) {
            wrapper.like("time", entity.getTime());
        }

        wrapper.orderBy("time desc");
        List<Check> resultList = CheckMapper.selectList(wrapper);
        return resultList;
    }

    @Override
    public List<Check> getList(String userId, String time, String state) {
        EntityWrapper<Check> wrapper = new EntityWrapper<>();
        if (ItdragonUtils.stringIsNotBlack(userId)) {
            wrapper.eq("userId", userId);
        }
        if (ItdragonUtils.stringIsNotBlack(state)) {
            wrapper.eq("state", state);
        }
        if (ItdragonUtils.stringIsNotBlack(time)) {
            wrapper.like("time", time);
        }
        wrapper.orderBy("time desc");
        List<Check> resultList = CheckMapper.selectList(wrapper);
        return resultList;

    }

    @Override
    public Check getOne(String id) {
        return CheckMapper.selectById(id);
    }


}