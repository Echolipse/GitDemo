package com.it.controller;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Car;
import com.it.entity.Property;
import com.it.entity.User;
import com.it.service.CarService;
import com.it.service.PropertyService;
import com.it.service.UserService;
import com.it.util.ItdragonUtils;
import com.it.util.Result;
import com.it.util.ResultResponse;
import com.it.util.TableResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 〈宿舍分配实列接口〉<br>
 *
 * @author
 */
@Controller
@RequestMapping("/car")
public class CarController {
    @Autowired
    private CarService CarService;
    @Autowired
    private ItdragonUtils itdragonUtils;
    @Autowired
    private UserService userService;
    @Autowired
    private PropertyService propertyService;

    /**
     * 管理界面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/index.do")
    public ModelAndView index(ModelAndView mv) {
        mv.setViewName("car/index");
        return mv;
    }

    /**
     * 管理界面列表数据异步加载接口
     *
     * @param entity
     * @param page
     * @param limit
     * @return
     */
    @ResponseBody
    @GetMapping("car.do")
    public TableResultResponse reloadTable(Car entity, int page, int limit) {
        List<Map<String, Object>> infoList = new ArrayList<>();
        Page<Car> pageInfo = CarService.selectPage(entity, page, limit);
        for (Car record : pageInfo.getRecords()) {
            Map<String, Object> resultMap = new HashMap<>(16);
            resultMap.put("id", record.getId());
            resultMap.put("proId", record.getProId());
            resultMap.put("name", record.getName());
            resultMap.put("userId", record.getUserId());
            resultMap.put("userName", record.getUserName());
            resultMap.put("realName", record.getRealName());
            infoList.add(resultMap);
        }
        return Result.tableResule(pageInfo.getTotal(), infoList);
    }

    /**
     * 新增界面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/addPage.do")
    public ModelAndView addPage(ModelAndView mv) {
        List<User> userList = userService.getUserInRole("035e6cd6738c42e5a4112d34e85e0832");
        mv.addObject("userList", userList);
        List<Property> propertyList = propertyService.getList(new Property());
        mv.addObject("propertyList", propertyList);
        mv.setViewName("car/addPage");
        return mv;
    }

    /**
     * 新增数据接口
     *
     * @param entity
     * @return
     */
    @ResponseBody
    @PostMapping("/car.do")
    public ResultResponse insert(Car entity) {
        //分配宿舍前先查询当前宿舍人数是不是满了
        //当前宿舍信息
        Property property = propertyService.getOne(entity.getProId());
        //当前宿舍人数
        Car car = new Car();
        car.setProId(entity.getProId());
        List<Car> list = CarService.getList(car);
        switch (property.getBrand()) {
            case "四人间":
                if (list.size() >= 4) {
                    return Result.resuleError("该宿舍下人数已满");
                }
                break;
            case "六人间":
                if (list.size() >= 6) {
                    return Result.resuleError("该宿舍下人数已满");
                }
                break;
            case "八人间":
                if (list.size() >= 8) {
                    return Result.resuleError("该宿舍下人数已满");
                }
                break;
        }
        //验证该学生是不是已被分配宿舍
        Car car1 = new Car();
        car1.setUserId(entity.getUserId());
        List<Car> list1 = CarService.getList(car1);
        if (!list1.isEmpty()) {
            return Result.resuleError("该学生已分配宿舍");
        }
        User user = userService.selectByPrimaryKey(entity.getUserId());
        entity.setRealName(user.getRealName());
        entity.setUserName(user.getUserName());
        entity.setName(property.getCode() + "-" + property.getName() + "-" + property.getBrand());
        boolean result = CarService.insert(entity);
        if (!result) {
            return Result.resuleError("新增失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 编辑界面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/editPage.do")
    public ModelAndView editPage(ModelAndView mv, String id) {
        Car car = CarService.getOne(id);
        mv.addObject("car", car);
        mv.setViewName("car/editPage");
        return mv;
    }

    /**
     * 编辑数据接口
     *
     * @param entity
     * @return
     */
    @ResponseBody
    @PutMapping("/car.do")
    public ResultResponse edit(Car entity) {
        boolean result = CarService.editById(entity);
        if (!result) {
            return Result.resuleError("编辑失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 删除数据接口
     *
     * @param id
     * @return
     */
    @ResponseBody
    @DeleteMapping("/car.do")
    public ResultResponse delete(String id) {
        boolean result = CarService.deleteById(id);
        if (!result) {
            return Result.resuleError("删除失败");
        }
        return Result.resuleSuccess();
    }


}