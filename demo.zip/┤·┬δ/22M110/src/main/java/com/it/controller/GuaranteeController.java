package com.it.controller;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Guarantee;
import com.it.entity.Property;
import com.it.service.GuaranteeService;
import com.it.service.PropertyService;
import com.it.util.ItdragonUtils;
import com.it.util.Result;
import com.it.util.ResultResponse;
import com.it.util.TableResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 〈报修相关实列接口〉<br>
 *
 * @author
 */
@Controller
@RequestMapping("/guarantee")
public class GuaranteeController {
    @Autowired
    private GuaranteeService GuaranteeService;
    @Autowired
    private ItdragonUtils itdragonUtils;
    @Autowired
    private PropertyService propertyService;

    /**
     * 管理界面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/index.do")
    public ModelAndView index(ModelAndView mv) {
        mv.setViewName("guarantee/index");
        return mv;
    }

    /**
     * 管理界面列表数据异步加载接口
     *
     * @param entity
     * @param page
     * @param limit
     * @return
     */
    @ResponseBody
    @GetMapping("guarantee.do")
    public TableResultResponse reloadTable(Guarantee entity, int page, int limit) {
        if ("035e6cd6738c42e5a4112d34e85e0832".equals(itdragonUtils.getSessionUser().getRoleId())) {
            entity.setUserName(itdragonUtils.getSessionUserName());
        }
        List<Map<String, Object>> infoList = new ArrayList<>();
        Page<Guarantee> pageInfo = GuaranteeService.selectPage(entity, page, limit);
        for (Guarantee record : pageInfo.getRecords()) {
            Map<String, Object> resultMap = new HashMap<>(16);
            resultMap.put("id", record.getId());
            resultMap.put("userName", record.getUserName());
            resultMap.put("content", record.getContent());
            resultMap.put("name", record.getName());
            resultMap.put("state", record.getState());
            resultMap.put("img", record.getImg());
            resultMap.put("reply", record.getReply());
            resultMap.put("roleId", itdragonUtils.getSessionUser().getRoleId());
            resultMap.put("time", record.getTime() == null ? "" : record.getTime().substring(0, 19));
            infoList.add(resultMap);
        }
        return Result.tableResule(pageInfo.getTotal(), infoList);
    }

    /**
     * 新增界面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/addPage.do")
    public ModelAndView addPage(ModelAndView mv) {
        List<Property> propertyList = propertyService.getList(new Property());
        mv.addObject("propertyList", propertyList);
        mv.setViewName("guarantee/addPage");
        return mv;
    }

    /**
     * 新增数据接口
     *
     * @param entity
     * @return
     */
    @ResponseBody
    @PostMapping("/guarantee.do")
    public ResultResponse insert(Guarantee entity) {
        boolean result = GuaranteeService.insert(entity);
        if (!result) {
            return Result.resuleError("新增失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 编辑界面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/editPage.do")
    public ModelAndView editPage(ModelAndView mv, String id) {
        Guarantee guarantee = GuaranteeService.getOne(id);
        mv.addObject("guarantee", guarantee);
        mv.setViewName("guarantee/editPage");
        return mv;
    }

    /**
     * 编辑数据接口
     *
     * @param entity
     * @return
     */
    @ResponseBody
    @PutMapping("/guarantee.do")
    public ResultResponse edit(Guarantee entity) {
        entity.setState("已处理");
        boolean result = GuaranteeService.editById(entity);
        if (!result) {
            return Result.resuleError("编辑失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 删除数据接口
     *
     * @param id
     * @return
     */
    @ResponseBody
    @DeleteMapping("/guarantee.do")
    public ResultResponse delete(String id) {
        boolean result = GuaranteeService.deleteById(id);
        if (!result) {
            return Result.resuleError("删除失败");
        }
        return Result.resuleSuccess();
    }

}