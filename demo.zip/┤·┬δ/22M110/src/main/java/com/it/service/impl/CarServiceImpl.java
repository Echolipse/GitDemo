package com.it.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Car;
import com.it.mapper.CarMapper;
import com.it.service.CarService;
import com.it.util.ItdragonUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 *
 *
 */
@Service
public class CarServiceImpl implements CarService {

    @Resource
    private ItdragonUtils itdragonUtils;
    @Resource
    private CarMapper CarMapper;

    @Override
    public Page<Car> selectPage(Car entity, int page, int limit) {
        EntityWrapper<Car> searchInfo = new EntityWrapper<>();
        Page<Car> pageInfo = new Page<>(page, limit);
        if (ItdragonUtils.stringIsNotBlack(entity.getUserId())) {
            searchInfo.eq("userId", entity.getUserId());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getUserName())) {
            searchInfo.like("userName", entity.getUserName());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getProId())) {
            searchInfo.eq("proId", entity.getProId());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getName())) {
            searchInfo.like("name", entity.getName());
        }
        List<Car> resultList = CarMapper.selectPage(pageInfo, searchInfo);
        if (!resultList.isEmpty()) {
            pageInfo.setRecords(resultList);
        }
        return pageInfo;
    }

    @Override
    public boolean insert(Car entity) {
        Integer insert = CarMapper.insert(entity);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean editById(Car entity) {
        Integer insert = CarMapper.updateById(entity);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteById(String ids) {
        String[] idList = ids.split(",");
        int result = 0;
        for (String s : idList) {
            result = CarMapper.deleteById(s);
        }
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public List<Car> getList(Car entity) {
        EntityWrapper<Car> wrapper = new EntityWrapper<>();
        if (ItdragonUtils.stringIsNotBlack(entity.getUserId())) {
            wrapper.eq("userId", entity.getUserId());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getUserName())) {
            wrapper.like("userName", entity.getUserName());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getProId())) {
            wrapper.eq("proId", entity.getProId());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getName())) {
            wrapper.like("name", entity.getName());
        }
        List<Car> resultList = CarMapper.selectList(wrapper);
        return resultList;
    }

    @Override
    public Car getOne(String id) {
        return CarMapper.selectById(id);
    }


}