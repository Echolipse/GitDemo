package com.it.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Come;
import com.it.mapper.ComeMapper;
import com.it.service.ComeService;
import com.it.util.DateUtil;
import com.it.util.ItdragonUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 〈一句话功能简述〉<br>
 *
 * @author
 * @create 2019/2/15 17:53
 * @since 1.0.0
 */
@Service
public class ComeServiceImpl implements ComeService {
    @Resource
    private ComeMapper ComeMapper;
    @Resource
    private ItdragonUtils itdragonUtils;

    @Override
    public Page<Come> selectPage(Come entity, int page, int limit) {
        EntityWrapper<Come> searchInfo = new EntityWrapper<>();
        Page<Come> pageInfo = new Page<>(page, limit);
        if (ItdragonUtils.stringIsNotBlack(entity.getNumber())) {
            searchInfo.eq("number", entity.getNumber());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getName())) {
            searchInfo.eq("name", entity.getName());
        }
        if (ItdragonUtils.stringIsNotBlack(entity.getContent())) {
            searchInfo.eq("content", entity.getContent());
        }
        List<Come> resultList = ComeMapper.selectPage(pageInfo, searchInfo);
        if (!resultList.isEmpty()) {
            pageInfo.setRecords(resultList);
        }
        return pageInfo;
    }

    @Override
    public boolean insert(Come entity) {
        entity.setTime(DateUtil.getNowDateSS());
        Integer insert = ComeMapper.insert(entity);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean delById(String id) {
        Integer delete = ComeMapper.deleteById(id);
        if (delete > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean edit(Come entity) {
        Integer update = ComeMapper.updateById(entity);
        if (update > 0) {
            return true;
        }
        return false;
    }

    @Override
    public Come getOne(String id) {
        return ComeMapper.selectById(id);
    }

    @Override
    public List<Come> getList(String userName, String time) {
        EntityWrapper<Come> wrapper = new EntityWrapper<>();
        wrapper.eq("userName", userName);
        wrapper.like("time", time);
        List<Come> selectList = ComeMapper.selectList(wrapper);
        return selectList;
    }
}