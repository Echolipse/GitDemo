package com.it.controller;

import com.it.entity.User;
import com.it.service.UserService;
import com.it.util.Result;
import com.it.util.ResultResponse;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * 图片上传
 */
@Controller
public class UploadController {
    @Autowired
    private UserService userService;
    public String result = "";

    @PostMapping("/upload.do")
    @ResponseBody
    public ResultResponse upload(MultipartFile file) {
        String fileName = "";
        try {
            fileName = file.getOriginalFilename();
            String destFileName = "D://User/" + File.separator + fileName;
            System.out.println(destFileName);
            File destFile = new File(destFileName);
            destFile.getParentFile().mkdirs();
            file.transferTo(destFile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return Result.resuleError("上传失败," + e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            return Result.resuleError("上传失败," + e.getMessage());
        }
        String url = "/image/" + fileName;
        return Result.resuleSuccess(url);
    }

    @PostMapping("/important.do")
    @ResponseBody
    public ResultResponse important(MultipartFile file) {
        String fileName = "";
        String destFileName = "";
        try {
            fileName = file.getOriginalFilename();
            destFileName = "E://User/" + File.separator + fileName;
            File destFile = new File(destFileName);
            destFile.getParentFile().mkdirs();
            file.transferTo(destFile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return Result.resuleError("文件上传失败," + e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            return Result.resuleError("文件上传失败," + e.getMessage());
        }
        boolean excel = false;
        try {
            excel = importExcel(destFileName, "2");
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (excel) {
            if (result.equals("")) {
                return Result.resuleSuccess(null, "全部导入");
            } else {
                String msg = result;
                result = "";
                return Result.resuleSuccess(null, msg);
            }

        }
        return Result.resuleError("存在重复数据!");
    }

    public boolean importExcel(String destFileName, String roldId) throws Exception {
        System.out.println(destFileName);
        String[] split = destFileName.split("\\.");
        if (split[1].equals("xlsx")) {
            XSSFWorkbook book = new XSSFWorkbook(new FileInputStream(ResourceUtils.getFile(destFileName)));
            XSSFSheet sheet = book.getSheetAt(0);
            for (int i = 0; i <= sheet.getLastRowNum(); i++) {
                User user = new User();
                XSSFRow row = sheet.getRow(i);
                //学号
                Cell cell0 = row.getCell(0);
                cell0.setCellType(Cell.CELL_TYPE_STRING);
                String userName = cell0.getStringCellValue();
                user.setUserName(userName);
                //姓名
                Cell cell1 = row.getCell(1);
                cell1.setCellType(Cell.CELL_TYPE_STRING);
                String realName = cell1.getStringCellValue();
                user.setRealName(realName);
                //专业
                Cell cell2 = row.getCell(2);
                cell2.setCellType(Cell.CELL_TYPE_STRING);
                String type = cell2.getStringCellValue();
                user.setType(type);
                //年龄
                Cell cell3 = row.getCell(3);
                cell3.setCellType(Cell.CELL_TYPE_STRING);
                String age = cell3.getStringCellValue();
                user.setAge(age);
                //身份证号
                Cell cell4 = row.getCell(4);
                cell4.setCellType(Cell.CELL_TYPE_STRING);
                String idCard = cell4.getStringCellValue();
                user.setIdCard(idCard);
                //身份证号
                Cell cell5 = row.getCell(5);
                cell5.setCellType(Cell.CELL_TYPE_STRING);
                String sex = cell5.getStringCellValue();
                user.setSex(sex);
                //手机号
                Cell cell6 = row.getCell(6);
                cell6.setCellType(Cell.CELL_TYPE_STRING);
                String iphone = cell6.getStringCellValue();
                user.setIphone(iphone);
                //手机号
                Cell cell7 = row.getCell(7);
                cell7.setCellType(Cell.CELL_TYPE_STRING);
                String emial = cell7.getStringCellValue();
                user.setEmail(emial);
                //手机号
                Cell cell8 = row.getCell(8);
                cell8.setCellType(Cell.CELL_TYPE_STRING);
                String address = cell8.getStringCellValue();
                user.setAddress(address);
                User checkUser = userService.getUserByUserName(user.getUserName());
                if (checkUser != null) {
                    return false;
                }
                boolean insert = userService.insert(user);
                if (!insert) {
                    return false;
                }
            }
        } else if (split[1].equals("xls")) {
            HSSFWorkbook hssfWorkbook = new HSSFWorkbook(new FileInputStream(ResourceUtils.getFile(destFileName)));
            HSSFSheet sheetAt = hssfWorkbook.getSheetAt(0);
            for (int i = 0; i <= sheetAt.getLastRowNum(); i++) {
                User user = new User();
                HSSFRow row = sheetAt.getRow(i);
                //学号
                Cell cell0 = row.getCell(0);
                cell0.setCellType(Cell.CELL_TYPE_STRING);
                String userName = cell0.getStringCellValue();
                user.setUserName(userName);
                //姓名
                Cell cell1 = row.getCell(1);
                cell1.setCellType(Cell.CELL_TYPE_STRING);
                String realName = cell1.getStringCellValue();
                user.setRealName(realName);
                //专业
                Cell cell2 = row.getCell(2);
                cell2.setCellType(Cell.CELL_TYPE_STRING);
                String type = cell2.getStringCellValue();
                user.setType(type);
                //年龄
                Cell cell3 = row.getCell(3);
                cell3.setCellType(Cell.CELL_TYPE_STRING);
                String age = cell3.getStringCellValue();
                user.setAge(age);
                //身份证号
                Cell cell4 = row.getCell(4);
                cell4.setCellType(Cell.CELL_TYPE_STRING);
                String idCard = cell4.getStringCellValue();
                user.setIdCard(idCard);
                //身份证号
                Cell cell5 = row.getCell(5);
                cell5.setCellType(Cell.CELL_TYPE_STRING);
                String sex = cell5.getStringCellValue();
                user.setSex(sex);
                //手机号
                Cell cell6 = row.getCell(6);
                cell6.setCellType(Cell.CELL_TYPE_STRING);
                String iphone = cell6.getStringCellValue();
                user.setIphone(iphone);
                //手机号
                Cell cell7 = row.getCell(7);
                cell7.setCellType(Cell.CELL_TYPE_STRING);
                String emial = cell7.getStringCellValue();
                user.setEmail(emial);
                //手机号
                Cell cell8 = row.getCell(8);
                cell8.setCellType(Cell.CELL_TYPE_STRING);
                String address = cell8.getStringCellValue();
                user.setAddress(address);
                User checkUser = userService.getUserByUserName(user.getUserName());
                if (checkUser != null) {
                    return false;
                }
                boolean insert = userService.insert(user);
                if (!insert) {
                    return false;
                }
            }
        }
        return true;
    }
}
