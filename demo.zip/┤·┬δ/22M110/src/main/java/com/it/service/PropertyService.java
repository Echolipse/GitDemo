package com.it.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Property;

import java.util.List;

public interface PropertyService {
    /**
     * 分页查询
     *
     * @param entity
     * @param page
     * @param limit
     * @return
     */
    Page<Property> selectPage(Property entity, int page, int limit);

    /**
     * 新增
     *
     * @param entity
     * @return
     */
    boolean insert(Property entity);

    /**
     * 编辑
     *
     * @param entity
     * @return
     */
    boolean editById(Property entity);

    /**
     * 删除
     *
     * @param ids
     * @return
     */

    boolean deleteById(String ids);

    /**
     * 获取集合
     *
     * @param entity
     * @return
     */
    List<Property> getList(Property entity);

    /**
     * 通过id查询单个对象
     *
     * @param id
     * @return
     */
    Property getOne(String id);

}
