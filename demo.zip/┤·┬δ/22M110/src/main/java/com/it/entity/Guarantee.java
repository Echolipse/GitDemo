package com.it.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;

import java.io.Serializable;

/**
 * 保修实体类
 */
@Data
@TableName("gm_guarantee")
public class Guarantee implements Serializable {
    /**
     * 自增长主键
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * 保修人员
     */
    private String userName;
    /**
     * 设备名称
     */
    private String name;
    private String proId;
    /**
     * 保修描述
     */
    private String content;
    private String reply;
    private String img;
    /**
     * 状态
     */
    private String state;
    /**
     * 创建时间
     */
    private String time;
}