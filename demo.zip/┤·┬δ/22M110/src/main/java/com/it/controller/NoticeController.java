package com.it.controller;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Notice;
import com.it.service.UserService;
import com.it.util.ItdragonUtils;
import com.it.util.Result;
import com.it.util.ResultResponse;
import com.it.util.TableResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 描述：〈公告管理相关接口/控制器〉
 */
@Controller
@RequestMapping("/notice")
public class NoticeController {
    @Autowired
    private com.it.service.NoticeService NoticeService;
    @Autowired
    private ItdragonUtils itdragonUtils;
    @Autowired
    private UserService userService;

    /**
     * 公告管理首页页面跳转
     * （将数据库中所有的菜单信息查询出来封装好传给前台，前台通过
     * layui-tree插件现实菜单数据）
     *
     * @param mv
     * @return
     */
    @RequestMapping("/index.do")
    public ModelAndView index(ModelAndView mv) {
        mv.setViewName("/notice/index");
        mv.addObject("roleId", itdragonUtils.getSessionUser().getRoleId());
        return mv;
    }

    /**
     * 异步加载公告信息列表
     *
     * @param notice
     * @param page
     * @param limit
     * @return
     */
    @ResponseBody
    @GetMapping("notice.do")
    public TableResultResponse reloadTable(int page, int limit, Notice notice) {
        List<Map<String, Object>> infoList = new ArrayList<>();
        Page<Notice> pageInfo = NoticeService.selectPage(notice, page, limit);
        for (Notice record : pageInfo.getRecords()) {
            Map<String, Object> resultMap = new HashMap<>(16);
            resultMap.put("id", record.getId());
            resultMap.put("title", record.getTitle());
            resultMap.put("content", record.getContent());
            resultMap.put("userName", record.getUserName());
            resultMap.put("urlA", "<a style='color:blue' href='" + record.getUrl() + "'>下载</a>");
            resultMap.put("time", record.getTime() == null ? "" : record.getTime().substring(0, 11));
            resultMap.put("roleId", itdragonUtils.getSessionUser().getRoleId());
            infoList.add(resultMap);
        }
        return Result.tableResule(pageInfo.getTotal(), infoList);
    }

    /**
     * 新增公告页面弹窗
     *
     * @return
     */
    @RequestMapping("/addPage.do")
    public ModelAndView addPage(ModelAndView mv) {
        mv.setViewName("/notice/addPage");
        return mv;
    }

    /**
     * 新增公告
     *
     * @param notice
     * @return
     */
    @PostMapping("/notice.do")
    @ResponseBody
    public ResultResponse insert(Notice notice) {
        boolean result = NoticeService.insert(notice);
        if (!result) {
            return Result.resuleError("新增失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 编辑公告页面弹窗
     *
     * @param id
     * @return
     */
    @RequestMapping("/editPage.do")
    public ModelAndView editPage(String id, ModelAndView mv) {
        Notice notice = NoticeService.getOne(id);
        mv.addObject("notice", notice);
        mv.setViewName("/notice/editPage");
        return mv;
    }

    /**
     * 编辑公告
     *
     * @param notice
     * @return
     */
    @PutMapping("/notice.do")
    @ResponseBody
    public ResultResponse edit(Notice notice) {
        boolean result = NoticeService.editById(notice);
        if (!result) {
            return Result.resuleError("编辑失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 删除公告
     *
     * @param id
     * @return
     */
    @DeleteMapping("/notice.do")
    @ResponseBody
    public ResultResponse delete(String id) {
        boolean result = NoticeService.deleteById(id);
        if (!result) {
            return Result.resuleError("删除失败");
        }
        return Result.resuleSuccess();
    }

}