package com.it.controller;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Check;
import com.it.entity.User;
import com.it.service.CheckService;
import com.it.service.UserService;
import com.it.service.WbeParameterService;
import com.it.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 〈实列接口〉<br>
 *
 * @author
 */
@Controller
@RequestMapping("/check")
public class CheckController {
    @Autowired
    private CheckService CheckService;
    @Autowired
    private ItdragonUtils itdragonUtils;
    @Autowired
    private UserService userService;
    @Autowired
    private WbeParameterService wbeParameterService;

    /**
     * 管理界面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/index.do")
    public ModelAndView index(ModelAndView mv) {
        mv.addObject("roleId", itdragonUtils.getSessionUser().getRoleId());
        mv.setViewName("check/index");
        return mv;
    }

    /**
     * 管理界面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/punch.do")
    public ModelAndView punch(ModelAndView mv) {
        mv.addObject("roleId", itdragonUtils.getSessionUser().getRoleId());
        mv.setViewName("check/punch");
        return mv;
    }

    /**
     * 管理界面列表数据异步加载接口
     *
     * @param entity
     * @param page
     * @param limit
     * @return
     */
    @ResponseBody
    @GetMapping("check.do")
    public TableResultResponse reloadTable(Check entity, int page, int limit) {
        List<Map<String, Object>> infoList = new ArrayList<>();
        if ("考勤".equals(entity.getType())) {
            if ("267b5a862b534ffea61b72f90bdcf6cc".equals(itdragonUtils.getSessionUser().getRoleId())) {
                entity.setUserId(itdragonUtils.getSessionUserId());
            }
        }
        if ("打卡".equals(entity.getType())) {
            if ("035e6cd6738c42e5a4112d34e85e0832".equals(itdragonUtils.getSessionUser().getRoleId())) {
                entity.setUserId(itdragonUtils.getSessionUserId());
            }
        }
        Page<Check> pageInfo = CheckService.selectPage(entity, page, limit);
        for (Check record : pageInfo.getRecords()) {
            Map<String, Object> resultMap = new HashMap<>(16);
            resultMap.put("id", record.getId());
            resultMap.put("userName", record.getUserName());
            resultMap.put("state", record.getState());
            resultMap.put("roleId", itdragonUtils.getSessionUser().getRoleId());
            resultMap.put("time", record.getTime() == null ? "" : record.getTime().substring(0, 19));
            infoList.add(resultMap);
        }
        return Result.tableResule(pageInfo.getTotal(), infoList);
    }

    /**
     * 新增界面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/addPage.do")
    public ModelAndView addPage(ModelAndView mv) {
        List<User> userList = userService.getUserInRole("267b5a862b534ffea61b72f90bdcf6cc");
        mv.addObject("userList", userList);
        mv.setViewName("check/addPage");
        return mv;
    }

    /**
     * 新增数据接口
     *
     * @param entity
     * @return
     */
    @ResponseBody
    @PostMapping("/check.do")
    public ResultResponse insert(Check entity) {
        Check check = new Check();
        check.setTime(DateUtil.getNowDate());
        check.setUserId(itdragonUtils.getSessionUserId());
        List<Check> checkList = CheckService.getList(check);
        if (!checkList.isEmpty()) {
            return Result.resuleError("今日不可重复提交数据");
        }
        boolean result = CheckService.insert(entity);
        if (!result) {
            return Result.resuleError("新增失败");
        }
        return Result.resuleSuccess();
    }


    /**
     * 删除数据接口
     *
     * @param ids
     * @return
     */
    @ResponseBody
    @DeleteMapping("/check.do")
    public ResultResponse delete(String ids) {
        boolean result = CheckService.deleteById(ids);
        if (!result) {
            return Result.resuleError("删除失败");
        }
        return Result.resuleSuccess();
    }
}