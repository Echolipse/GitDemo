package com.it.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;

import java.io.Serializable;

/**
 * 实体类
 */
@Data
@TableName("gm_check")
public class Check implements Serializable {
    /**
     * 自增长主键
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * 用户
     */
    private String userId;
    private String userName;
    /**
     * 考勤时间
     */
    private String time;
    /**
     * 状态
     */
    private String state;
    /**
     * 类型
     */
    private String type;
}